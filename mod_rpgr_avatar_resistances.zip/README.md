# Avatar_Resistances
Configurable resistances against non-standard attacks and states for player characters.
